#provide startup information
echo -e ""
echo -e "\e[91m\e[1mUsername:\e[49m\e[0m"
echo -e "\e[91mthesis\e[49m"
echo -e "\e[91m\e[1mPassword:\e[49m\e[0m"
echo -e "\e[91m12CyberCyberBigDataCloud34%&\e[49m"
echo -e ""
echo -e "\e[91mplease change credentials in the usermanagement before use\e[39m\e[0m"
echo -e "\e[91mthis is not a production webserver nor has the application been hardened for production use. Deactivate DEBUG=True in settings.py to increase security.\e[39m\e[0m"

#Start the server at localhost:8000
python3 manage.py runserver
