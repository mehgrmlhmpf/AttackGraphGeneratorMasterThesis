"""EmAGra URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include, path, re_path
from django.views.generic import RedirectView

#event for sentry testing www.sentry.io
def trigger_error(request):
    division_by_zero = 1 / 0
    print(division_by_zero)

urlpatterns = [
    path('sentry-debug/', trigger_error), # sentry.io debug functionality
    path(r'graphs/', include('graphs.urls')),
    path(r'admin/', admin.site.urls), # admin sites
    path(r'', RedirectView.as_view(url="/graphs/")),
    path('accounts/', include('django.contrib.auth.urls')),
    path('admin/doc/', include('django.contrib.admindocs.urls')), # add documentation link to admin interface 
]
