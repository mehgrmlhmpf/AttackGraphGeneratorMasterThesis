# Installation instructions contained in INSTALL.txt

# Initial User:Password Setup:
# -> thesis:12CyberCyberBigDataCloud34%&

# Application root folder is EmAGra (emulation attack graphs)

#Database has already been setup

# Starting the application (please note, that a folder EmAGra is contained in the root, indicating the django application)
# Activate virtual python environment:
source ./EmAGra/bin/activate

# Start the server at localhost:8000
python3 manage.py runserver
