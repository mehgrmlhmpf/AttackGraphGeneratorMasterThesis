#!/bin/bash

#Required: Fresh install of Ubuntu 20.10 or similiar
#Application root folder is EmAGra (emulation attack graphs)

#Activate virtual python environment:
source ./EmAGra/bin/activate

#Update package sources
sudo apt update

#Install python packet manager
sudo apt install python3-pip

#Install graphviz dependencies
sudo apt-get install python3-dev graphviz libgraphviz-dev pkg-config

#Install Python libraries
pip install -r requirements.txt

echo -e ""
echo -e "\e[91m\e[1mUsername:\e[49m\e[0m"
echo -e "\e[91mthesis\e[49m"
echo -e "\e[91m\e[1mPassword:\e[49m\e[0m"
echo -e "\e[91m12CyberCyberBigDataCloud34%&\e[49m"
echo -e ""
echo -e "\e[91mplease change credentials in the usermanagement before use\e[39m\e[0m"
echo -e "\e[91mthis is not a production webserver nor has the application been hardened for production use. Deactivate DEBUG=True in settings.py to increase security.\\e[39m\e[0m"

#Start the server at localhost:8000
python3 manage.py runserver
