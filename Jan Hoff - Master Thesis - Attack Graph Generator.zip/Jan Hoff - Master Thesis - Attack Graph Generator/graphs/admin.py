from django.contrib import admin
from import_export.admin import ImportExportModelAdmin  # pylint: disable=import-error,unused-import
from .models import Technique, Node, Tactic, AttackGraph, ThreatActor, Ioc, Target
from .resources import NodeResource, TechniqueResource, TargetResource, IocResource, ThreatActorResource, AttackGraphResource, TacticResource
from .forms import TacticAdminForm


class NodeAdmin(ImportExportModelAdmin):
    """Class for administration of nodes with import and export

    Args:
        ImportExportModelAdmin ([type]): [description]

    Returns:
        [type]: [description]
    """
    resource_class = NodeResource
    filter_horizontal = ('predecessor', 'successor')
    list_display = ('technique', 'tactic', 'graph', 'status', 'result')

    def formfield_for_manytomany(self, db_field, request, **kwargs):
        # only reduce the available nodes if a graph exists (object_id is available)
        if 'object_id' in request.resolver_match.kwargs:
            node_id = int(request.resolver_match.kwargs['object_id'])
            # reduce the self-references to the available nodes for the graph_id
            if db_field.name == "predecessor":
                kwargs["queryset"] = Node.objects.filter(
                    graph_id=Node.objects.filter(id=node_id).get().graph_id).order_by('-rank')
            # reduce the self-references to the available nodes for the graph_id
            if db_field.name == "successor":
                kwargs["queryset"] = Node.objects.filter(
                    graph_id=Node.objects.filter(id=node_id).get().graph_id).order_by('-rank')
        return super().formfield_for_manytomany(db_field, request, **kwargs)


class AttackGraphAdmin(ImportExportModelAdmin):
    """Class for administration of AttackGraphs with import and export

    Args:
        ImportExportModelAdmin ([type]): [description]

    Returns:
        [type]: [description]
    """
    resource_class = AttackGraphResource

    list_display = ('id', 'name', 'status', 'create_date')
    search_fields = ['name', 'desc']
    filter_horizontal = ('startnode',)

    # reduce the startnodes to the available startnodes for the graph_id

    def formfield_for_manytomany(self, db_field, request, **kwargs):
        attackgraph_id = int(request.resolver_match.kwargs['object_id'])
        if db_field.name == "startnode":
            kwargs["queryset"] = Node.objects.filter(
                graph_id=attackgraph_id).order_by('-rank')
        return super().formfield_for_manytomany(db_field, request, **kwargs)


class TechniqueAdmin(ImportExportModelAdmin):
    """Class for administration of Techniques with import and export

    Args:
        ImportExportModelAdmin ([type]): [description]

    Returns:
        [type]: [description]
    """
    list_display = ('name', 'get_tactics')
    filter_horizontal = ('tactic', 'target_restriction', 'predecessor',
                         'successor', 'prerequisite', 'group_association', 'ioc_restriction')
    search_fields = ['name', 'desc']

    def formfield_for_manytomany(self, db_field, request, **kwargs):
        if db_field.name == "prerequisite":
            kwargs["queryset"] = Technique.objects.all().order_by('-tactic__level')
        return super().formfield_for_manytomany(db_field, request, **kwargs)

    # https://stackoverflow.com/questions/18108521/many-to-many-in-list-display-django/18108586
    def get_tactics(self, obj):
        return ", ".join([t.name for t in obj.tactic.all()])

    def get_ordering(self, request):
        return ['-tactic__level']  # sort case insensitive

    resource_class = TechniqueResource


class TargetAdmin(ImportExportModelAdmin):
    """Class for administration of Targets with import and export

    Args:
        ImportExportModelAdmin ([type]): [description]
    """
    resource_class = TargetResource


class IocAdmin(ImportExportModelAdmin):
    """Class for administration of IOC with import and export

    Args:
        ImportExportModelAdmin ([type]): [description]
    """
    resource_class = IocResource
    filter_horizontal = ('attribution',)
    list_display = ('name', 'desc', 'iocType', 'source')



class ThreatActorAdmin(ImportExportModelAdmin):
    """Class for administration of Groups/Threat Actor with import and export

    Args:
        ImportExportModelAdmin ([type]): [description]
    """
    resource_class = ThreatActorResource


class TacticAdmin(ImportExportModelAdmin):
    """Class for administration of Tactics with import and export

    Args:
        ImportExportModelAdmin ([type]): [description]
    """
    form = TacticAdminForm
    # fieldsets = (
    #    (None, {
    #        'fields': ('name', 'desc', 'color')
    #        }),
    #    )
    resource_class = TacticResource
    list_display = ('name', 'level')


#Register all administrative functions with the administrative backend
admin.site.register(Tactic, TacticAdmin)
admin.site.register(AttackGraph, AttackGraphAdmin)
admin.site.register(ThreatActor, ThreatActorAdmin)
admin.site.register(Ioc, IocAdmin)
admin.site.register(Target, TargetAdmin)
admin.site.register(Node, NodeAdmin)
admin.site.register(Technique, TechniqueAdmin)
