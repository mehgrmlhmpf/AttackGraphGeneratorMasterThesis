from django.urls import path, include, re_path
from . import views
from django.contrib import admin
#static content in "non debug mode", for prototype. for production use dedicated static server
from django.views.static import serve 
from django.conf import settings

# Rename standard names
admin.site.site_header = 'Administration'               # default: "Django Administration"
admin.site.index_title = 'Administration'               # default: "Site administration"
admin.site.site_title = 'Emulation Attack Graphs Admin' # default: "Django site admin"

# create URL patterns to map the right view to the right function
urlpatterns = [
    path('', views.index, name='index'),
    path('database', views.database, name='database'),
    path('system', views.system, name='system'),
    path('render/<int:graph_id>/<str:graph_format>/', views.render_graph, name='render_graph'),
    path('render/<int:graph_id>/<str:graph_format>/<int:reductionlevel>', views.render_graph, name='render_graph'),
    path('show/<int:graph_id>/node/<int:node_id>/', views.show_node, name='show_node'),
    path('show/<int:graph_id>/', views.show_graph, name='show_graph'),
    path('ajax/update/<int:graph_id>/node/<int:node_id>/', views.update_node, name='update_node'),
    path('new', views.new, name='new'),
    path('all', views.show_all, name='show_all'),
    path('apt-name-generator', views.apt_name_generator, name='apt_name_generator'),
    #add static files, for production use dedicated static server
    re_path(r'^media/(?P<path>.*)$', serve,{'document_root': settings.MEDIA_ROOT}), 
    re_path(r'^static/(?P<path>.*)$', serve,{'document_root': settings.STATIC_ROOT}), 
]
