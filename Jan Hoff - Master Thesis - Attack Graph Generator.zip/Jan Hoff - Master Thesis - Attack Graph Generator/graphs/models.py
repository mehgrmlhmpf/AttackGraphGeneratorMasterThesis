from django.db import models
from django.db.models import Avg, Max, Min, Sum
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver

# following are all database models with tables and fields

class Tactic(models.Model):
    """Tactic according to ATT&CK and thesis database design

    Args:
        models ([type]): [description]

    Returns:
        [type]: [description]
    """
    name = models.CharField(max_length=200)
    desc = models.TextField()
    color = models.CharField(max_length=7)
    level = models.IntegerField()

    def __str__(self):
        return "{}".format(self.name)

    def __repr__(self):
        return self.__str__()


class Target(models.Model):
    """Targets according to ATT&CK and thesis database design

    Args:
        models ([type]): [description]

    Returns:
        [type]: [description]
    """
    IT_OT_CHOICES = [
        ('IT', 'IT only'), ('OT', 'OT only'), ('*', 'any'), ('NA', 'N/A'),
    ]
    ONE_MANY_CHOICES = [
        ('1', 'specific target'), ('N', 'multiple targets'), ('0', 'N/A'),
    ]
    name = models.CharField(max_length=200)
    desc = models.TextField(null=True)
    location = models.CharField(
        max_length=2, choices=IT_OT_CHOICES, default='any')
    one_many = models.CharField(
        max_length=1, choices=ONE_MANY_CHOICES, default='N/A')

    def __str__(self):
        return "{}".format(self.name)

    def __repr__(self):
        return self.__str__()


class ThreatActor(models.Model):
    """Groups according to ATT&CK and thesis database design

    Args:
        models ([type]): [description]

    Returns:
        [type]: [description]
    """
    CLASSES = [
        ('CRI', 'Cybercrime'), ('TRL', 'Hacktivists'), ('NST',
                                                        'Nationstate'), ('NA', 'N/A'),
    ]
    name = models.CharField(max_length=200)
    alternative_names = models.CharField(max_length=200, null=True)
    desc = models.TextField()
    classification = models.CharField(
        max_length=3, choices=CLASSES, default='N/A')
    country = models.CharField(max_length=200, default='N/A')
    reference = models.CharField(max_length=200, null=True)
    sector = models.CharField(max_length=200, null=True)

    def __str__(self):
        return "{}".format(self.name)

    def __repr__(self):
        return self.__str__()


class Technique(models.Model):
    """Techniques according to ATT&CK and thesis database design

    Args:
        models ([type]): [description]

    Returns:
        [type]: [description]
    """
    name = models.CharField(max_length=200)
    desc = models.TextField()
    tactic = models.ManyToManyField(Tactic, related_name='tactic')
    source = models.CharField(max_length=300)
    TID = models.CharField(max_length=200, blank=True, null=True)
    mitigation = models.TextField(blank=True, null=True)
    detection = models.TextField(blank=True, null=True)
    custom = models.BooleanField()  # is technique MITRE default or user custom?
    target_restriction = models.ManyToManyField(
        'Target', blank=True, related_name='target_restriction')
    ioc_restriction = models.ManyToManyField(
        'Ioc', blank=True, related_name='ioc_restriction')
    successor = models.ManyToManyField(
        'self', blank=True, related_name='technique_next', symmetrical=False)
    predecessor = models.ManyToManyField(
        'self', blank=True, related_name='technique_prev', symmetrical=False)
    # all previous techniques, which must be completed.
    prerequisite = models.ManyToManyField(
        'self', blank=True, related_name='technique_prereq', symmetrical=False)
    group_association = models.ManyToManyField(
        'ThreatActor', blank=True, related_name='group_association')
    conjunction = models.BooleanField()
    disjunction = models.BooleanField()
    maintain_previous_target = models.BooleanField()
    create_date = models.DateTimeField('date created')
    update_date = models.DateTimeField('date updated')
    comment = models.TextField(null=True, blank=True)

    #deduct Meta-Technique attribute with a property function
    @property
    def is_meta(self):
        meta = False
        if self.conjunction or self.disjunction:
            meta = True
        return meta 

    def __str__(self):
        return "{}".format(self.name)

    def __repr__(self):
        return self.__str__()


class AttackGraph(models.Model):
    """AttackGraph as collector for instantiated techniques according thesis database design

    Args:
        models ([type]): [description]

    Returns:
        [type]: [description]
    """
    STATUS = [
        ('0', 'created'), ('1', 'ready'), ('2',
                                           'work in progress'), ('3', 'completed'),
    ]
    name = models.CharField(max_length=200)
    desc = models.TextField()
    startnode = models.ManyToManyField('Node')
    create_date = models.DateTimeField('date created')
    status = models.CharField(
        max_length=1, choices=STATUS, default='0')
    comment = models.TextField(blank=True, null=True)
    constraints = models.TextField(blank=True, null=True)

    def __str__(self):
        return "{}".format(self.name)

    def __repr__(self):
        return self.__str__()
        
class Ioc(models.Model):
    """IOC according to thesis database design

    Args:
        models ([type]): [description]

    Returns:
        [type]: [description]
    """
    TYPE = [
        ('N', 'Network'), ('H', 'Host'), ('X', 'n/a'),
    ]
    name = models.CharField(max_length=200)
    desc = models.TextField(null=True)
    fragment = models.FileField(null=True, upload_to='media/')
    iocType = models.CharField(
        max_length=1, choices=TYPE, default='X')
    source = models.CharField(max_length=200, null=True)
    attribution = models.ManyToManyField(
        'ThreatActor', blank=True, related_name='threat_association')


    def __str__(self):
        return "{}".format(self.name)

    def __repr__(self):
        return self.__str__()

class Node(models.Model):
    """Instantiated Techniques according to thesis database design and attack graph designs

    Args:
        models ([type]): [description]

    Returns:
        [type]: [description]
    """
    STATUS = [
        ('0', 'open'), ('1', 'work in progress'), ('2', 'executed'),
    ]
    RESULTS = [
        ('0', 'successful'), ('1', 'partial'), ('2', 'unsuccessful'), ('3', 'n/a'),
    ]
    technique = models.ForeignKey(Technique, on_delete=models.CASCADE)
    graph = models.ForeignKey(AttackGraph, on_delete=models.CASCADE)
    tactic = models.ForeignKey(Tactic, on_delete=models.CASCADE, null=True)
    target = models.ForeignKey(Target, on_delete=models.CASCADE, null=True)
    rank = models.IntegerField()
    status = models.CharField(
        max_length=1, choices=STATUS, default='0')
    result = models.CharField(
        max_length=1, choices=RESULTS, default='3', null=True, blank=True)
    result_comment = models.TextField(blank=True, null=True)
    successor = models.ManyToManyField(
        'self', blank=True, related_name='node_next', symmetrical=False)
    predecessor = models.ManyToManyField(
        'self', blank=True, related_name='node_prev', symmetrical=False)
    ioc = models.ForeignKey(
        Ioc, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return "{}: {} -> {}".format(self.id, self.graph, self.technique)

    def __repr__(self):
        return self.__str__()
    
    # use property to calculate meta-results
    @property
    def get_result(self):
        result = self.result 
        if self.technique.disjunction:
            result = self.predecessor.all().aggregate(Max('result'))['result__max']
        #if self.technique.conjunction:
        #    result = self.predecessor.all().aggregate(Min('result'))['result__min']
        return result 

@receiver(pre_save, sender=Node, dispatch_uid="update_result")
def update_result(sender, instance, **kwargs):
    """Instantiate a pre_save receiver to update node results dynamically on information changes.

    Args:
        sender ([type]): [description]
        instance ([type]): [description]
    """
    if not instance.pk is None:
        result = instance.get_result
        instance.result = result
    #instance.save()

    #override save for Meta-Technique result calculation
    # def save(self, *args, **kwargs):
    #     if self.technique.is_meta:
    #         self.result = self.get_result(self)        
    #     super().save(*args, **kwargs)
    
    # def attrs(self):
    #     for attr, value in self.__dict__.items():
    #         yield attr, value
