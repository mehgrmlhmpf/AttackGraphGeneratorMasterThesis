# Enumeration definitions and statics

# Status of nodes
STATUS = [
    ('0', 'open'), ('1', 'work in progress'), ('2', 'executed'),
]

# Results of nodes
RESULTS = [
    ('0', 'successful'), ('1', 'partial'), ('2', 'unsuccessful'), ('3', 'n/a'),
]

# Status of graphs
STATUS_GRAPH = [
    ('0', 'created'), ('1', 'ready'), ('2', 'work in progress'), ('3', 'completed'),
]