from import_export import resources  # pylint: disable=import-error,unused-import
from .models import Technique, Node, Tactic, AttackGraph, ThreatActor, Ioc, Target

#create Resources for export and import functionality in admin interface
#https://django-import-export.readthedocs.io/en/latest/getting_started.html#creating-import-export-resource

class NodeResource(resources.ModelResource):
    class Meta:
        model = Node

class TechniqueResource(resources.ModelResource):
    class Meta:
        model = Technique

class TacticResource(resources.ModelResource):
    class Meta:
        model = Tactic

class AttackGraphResource(resources.ModelResource):
    class Meta:
        model = AttackGraph

class ThreatActorResource(resources.ModelResource):
    class Meta:
        model = ThreatActor

class IocResource(resources.ModelResource):
    class Meta:
        model = Ioc

class TargetResource(resources.ModelResource):
    class Meta:
        model = Target


