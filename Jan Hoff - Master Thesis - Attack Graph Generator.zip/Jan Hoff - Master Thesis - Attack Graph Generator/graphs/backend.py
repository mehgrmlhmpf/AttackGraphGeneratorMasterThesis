import string
import random as rnd
from django.utils import timezone
import networkx as nx
import pygraphviz as pgv  # pylint: disable=import-error,unused-import
from PIL import Image  # pylint: disable=import-error,unused-import
from .models import AttackGraph, Node, Technique, ThreatActor, Tactic, Target, Ioc  # pylint: disable=import-error,unused-import
from django.core.exceptions import ObjectDoesNotExist
from itertools import chain
from django.db.models import Max, Min
import numpy as np
import json


def generate_graph_constrained(name, desc, max_width, min_width, constraints, num_overstep, spread):
    """Function to generate attack graph based on given constraints.

    Args:
        name (String): Name of the adversary/attack graph/profile
        desc (String): description
        min_width (Int): min number of nodes per Tactic
        max_width (Int):  max number of nodes per Tactic
        constraints (String): Constraints, that are provided by an operator
        num_overstep (Int): Number of steps references backwards are allowed (default one Tactic earlier)
        spread (Int): Modification of power-law distribution function

    Returns:
        attackgraph : Attack graph object
    """
    # save all constraints to graph
    attackgraph = AttackGraph(name=name, desc=desc, create_date=timezone.now(), constraints=str(
        constraints)+", max_width="+str(max_width)+", overstep="+str(num_overstep)+", spread="+str(spread))
    attackgraph.save()
    # restrict all Tactics to ICS only for the prototype, database only has ICS Tactics though
    allowed_tactics = Tactic.objects.filter(
        name__icontains="ICS").order_by('-level')
    allowed_techniques = Technique.objects.all()
    allowed_targets = Target.objects.all()
    allowed_iocs = Ioc.objects.all()

    # set up constraints on knowledge base
    if constraints["tactics"]:
        allowed_tactics = allowed_tactics.exclude(
            pk__in=constraints["tactics"])
    if constraints["techniques"]:
        allowed_techniques = allowed_techniques.exclude(
            pk__in=constraints["techniques"])
    if constraints["targets"]:
        allowed_targets = allowed_targets.exclude(
            pk__in=constraints["targets"])
    if constraints["iocs"]:
        allowed_iocs = allowed_iocs.exclude(pk__in=constraints["iocs"])
    if constraints["groups"]:
        allowed_techniques = allowed_techniques.exclude(group_association__in=constraints["groups"])

    # IndexError at /graphs/new Cannot choose from an empty sequence - no techniques to choose from -- error out
    # handle empty sets to choose from
    if not allowed_iocs or not allowed_tactics or not allowed_targets or not allowed_techniques:
        return

    # Iterate over all Tactics allowed
    for selected_tactic in allowed_tactics:
        try:
            # select one technique of tactic to instantiate, use sample for unique and choices for possible repetition
            for selected_technique in rnd.choices(list(allowed_techniques.filter(tactic=selected_tactic)), k=rnd.randint(min_width, max_width)):
                # if selected_technique does not fulfil the required predecessors, then do not add the technique
                if selected_technique.prerequisite.all() and not Node.objects.filter(graph_id=attackgraph.id).filter(technique__in=selected_technique.prerequisite.all()):
                    continue  # exit current iteration if prerequisites are not empty and prereq are not in the current graph

                # select a target for selected technique
                target = select_target(selected_technique, allowed_targets)
                # select an IOC for selected technique
                ioc = select_IOC(selected_technique, allowed_iocs)

                # instantiate a new node with selected technique and associate it with target and IOC
                # use not execute and no result as a standard instantiation
                new_node = Node(technique=selected_technique, graph=attackgraph, tactic=selected_tactic,
                                target=target, ioc=ioc, rank=selected_tactic.level, result=3, status=0)
                new_node.save()

               
                # generate successor/predecessor edges
                if not selected_tactic.level == allowed_tactics.aggregate(Max('level'))['level__max']:
                    generate_edges(attackgraph, new_node, num_overstep, spread, max_width)
                
                # set start_nodes to highest tactic
                if selected_tactic.level == allowed_tactics.aggregate(Max('level'))['level__max']:
                    attackgraph.startnode.add(new_node)
                    attackgraph.save()

                # generate meta node dependencies
                if selected_technique.is_meta:
                    generate_meta_node(attackgraph, selected_technique, new_node, allowed_targets)

                # modify targets, if maintain target is set

        # handle exceptions
        except ValueError as population_error:
            print("Issue with population " + str(population_error))
        except IndexError as indexerror:
            print(
                "Index error - skipping Tactic due to unavailable constraints - " + str(indexerror))

    # get all nodes
    all_nodes = Node.objects.filter(graph_id=attackgraph.id)
    highest_tactic_level = all_nodes.aggregate(Max('tactic__level'))[
        'tactic__level__max']

    # add successor
    for i in (range(0, highest_tactic_level)):
        nodes_per_tactic = all_nodes.filter(tactic__level=i).all()
        for node in nodes_per_tactic:
            for predecessor in node.predecessor.all():
                predecessor.successor.add(node)

    return attackgraph

def generate_meta_node(attackgraph, selected_technique, meta_node, allowed_targets):
    """Function to generate meta nodes.

    Args:
        attackgraph ([type]): [description]
        selected_technique ([type]): [description]
        new_node ([type]): [description]
        allowed_targets ([type]): [description]
    """
    # iterate of all predecessors and instantiate
    for technique in selected_technique.predecessor.all():
        target = select_meta_target(technique, allowed_targets)
        new_node = Node(technique=technique, graph=attackgraph, tactic=technique.tactic.first(
        ), target=target, rank=technique.tactic.first().level, result=3, status=0)
        new_node.save()
        meta_node.save()
        #after instantiation add relationships and save again, else error (since FK is missing)
        new_node.successor.add(meta_node)
        meta_node.predecessor.add(new_node)
        new_node.save()
        meta_node.save()
    # iterate of all successors and instantiate
    for technique in selected_technique.successor.all():
        target = select_meta_target(technique, allowed_targets)
        new_node = Node(technique=technique, graph=attackgraph, tactic=technique.tactic.last(
        ), target=target, rank=technique.tactic.first().level, result=3, status=0)
        new_node.save()
        meta_node.save()
        #after instantiation add relationships and save again, else error (since FK is missing)
        new_node.predecessor.add(meta_node)
        meta_node.successor.add(new_node)
        new_node.save()
        meta_node.save()

def create_required_node():
    """ TODO Instantiation of prerequisite nodes
    """
    pass

def select_meta_target(selected_technique,allowed_targets):
    """Function to select targets for meta techniques

    Args:
        selected_technique ([type]): [description]
        allowed_targets ([type]): [description]

    Returns:
        target: a target object to be added to a Technique
    """
    target = select_target(selected_technique, allowed_targets)
    return target

def generate_edges(attackgraph, node, num_overstep, spread, max_width):
    """Function to generate edges and save nodes with new parameters.

    Args:
        attackgraph ([type]): [description]
        node ([type]): [description]
        num_overstep ([type]): [description]
        spread ([type]): [description]
        max_width ([type]): [description]
    """
    all_nodes = Node.objects.filter(graph_id=attackgraph.id)
    for _node in all_nodes:
        # have at least one possibility of predecessor
        available_predecessors = []
        overstep_correction = 0

        while not available_predecessors:
            available_predecessors = all_nodes.filter(
                rank__range=(node.tactic.level+1, node.tactic.level+num_overstep+overstep_correction))
            overstep_correction += 1

    # create logarithmic distribution / powerlaw
    # possibility to manipulate distribution with spread variable
    probability = np.logspace(0, spread, base=5.0, num=max_width)
    # normalize for probability distribution
    probability /= probability.sum()
    # the more edges we already have the less likely an edge is
    # no edges ist most unlikely, then maximum edges, 1 edge ist most likely
    number_of_edges = np.random.choice(a=[0]+list(range(1, max_width)[::-1]), p=probability, size=1)
    for predecessor in available_predecessors.order_by('?')[:number_of_edges]:
        node.predecessor.add(predecessor)
    node.save()
    

def select_target(selected_technique, allowed_targets):
    """Function to select a Target for a given Technique.

    Args:
        selected_technique ([type]): [description]
        allowed_targets ([type]): [description]

    Returns:
        Target: target for a Techqniue
    """
    technique_targets = selected_technique.target_restriction.all()
    # target selection based on constraints and available targets in technique
    if selected_technique.maintain_previous_target:
        # associate a random target, that will be changed after edge generation
        target = rnd.choice(allowed_targets)  
    else:
        if technique_targets:
            target = rnd.choice(
                allowed_targets.intersection(technique_targets))
        else:
            target = rnd.choice(allowed_targets)
    return target

def select_IOC(selected_technique, allowed_iocs):
    """Function to select an IOC for a Technique

    Args:
        selected_technique ([type]): [description]
        allowed_iocs ([type]): [description]

    Returns:
        IOC: IOC for a Technique
    """
    technique_iocs = selected_technique.ioc_restriction.all()
    # target selection based on constraints and available targets in technique
    if technique_iocs:
        if allowed_iocs.intersection(technique_iocs):
            ioc = rnd.choice(
                allowed_iocs.intersection(technique_iocs))
        else:
            # no valid
            ioc = None
    else:
        # all IOC are allowed, for demonstration purposes, randomly pick one. In production, do not set an IOC when empty
        ioc = rnd.choice(allowed_iocs)
    return ioc


def render_img_graph(graph_id, graph_format, reductionlevel):
    """Renders a graphs to a given format. Depending on the reduction
    level given to the graph nodes are going to be hidden, if they do not have enough edges.
    This cleans up the graph visually.

    Args:
        graph_id (int): id of the graph that should be rendered
        reductionlevel (int): the minimal number of edges a node needs before it is added to the rendering
        graph_format (string): the format, which to render in

    Returns:
        image/json: image/export of the graph
    """
    try:
        name = AttackGraph.objects.filter(id=graph_id).get().name
    except ObjectDoesNotExist as doesnotexist_error:
        name = doesnotexist_error
    G = build_digraph(graph_id, name, reductionlevel)
    agraph = nx.nx_agraph.to_agraph(G)
    agraph.graph_attr['label'] = str(name)
    # add ranked levels
    for i in range(0, 10):
        same_level_nodes = chain([Tactic.objects.filter(name__icontains="ICS", level=(
            i)).first()], Node.objects.filter(graph=graph_id, rank=i).all())
        _ = agraph.add_subgraph(same_level_nodes, rank='same')

    # create SVG in memory and create response
    agraph.layout('dot')
    # , {"link": "edges", "source": "from", "target": "to"})
    if graph_format == "JSON":
        data2 = nx.json_graph.node_link_data(G)
        return json.dump(data2, f, indent=4)
    else:
        return agraph.draw(format=graph_format)


def build_digraph(graph_id, name, reductionlevel):
    """Build a directed graph based on the provided graphid

    Args:
        graph_id (int): ID of the graph, that should be rendered
        name (string): name of th graph
        reductionlevel (int): if provided, remove nodes from graph rendering without the minimal umber of edges

    Returns:
        digraph : a directed graph with all nodes and edges for a graph ID
    """
    G = nx.DiGraph()
    startnodes = Node.objects.filter(attackgraph__id=graph_id)
    for node in startnodes:
        G.add_node(node.id, label=str(node), rank=0,
                   fillcolor=node.tactic.color, style="filled", fontname='helvetica ')

    # create nodes
    for x in Node.objects.filter(graph=graph_id):
        style, shape, fillcolor = format_node(x)

        if not x.technique.is_meta:
            G.add_node(str(x.id), label=str(x.technique.name)+" against\n"+x.target.name,
                       rank=x.rank, fillcolor=fillcolor, style=style, color="black", shape=shape, fontname='helvetica')
        else:
            # draw "empty" node, when Meta-Technique
            G.add_node(str(x.id), label="", shape="none",
                       height=.0, width=.0, fillcolor="grey")

        # render edges
        # iterate over all predecessors
        for y in Node.objects.filter(predecessor=x):
            # str(rnd.randint(0, 100))+"%")
            style, color, label = format_edge(x)
            #label = x.get_result_display()
            G.add_edge(str(x.id), str(y.id), label=label,
                       style=style, color=color, arrowhead="normal", arrowsize=.8, weight=1.)  # arrowsize 2.0 too big

    # create pseudo nodes and edges for "ends", end in small circle for terminal activities
    for z in Node.objects.filter(graph=graph_id).filter(successor__isnull=True):
        style, color, label = format_edge(z)
        G.add_node(str(z.id)+"_", label="", rank=z.rank +
                   1, style="invis", fillcolor="white")
        G.add_edge(str(z.id), str(z.id)+"_", label=label,
                   style=style, color=color, arrowhead="dot", arrowsize=.8, weight=1.,)

    all_nodes = Node.objects.filter(graph_id=graph_id)
    highest_tactic_level = all_nodes.aggregate(Max('tactic__level'))[
        'tactic__level__max']

    # set to true if "legend" should be added to graphs, works best for "full" graphs
    mitre_layout = True
    if mitre_layout:
        # add MITRE layout (optional)
        for z in Tactic.objects.filter(name__icontains="ICS"):
            G.add_node(str(z.id), label=str(
                z), rank=z.level, fontname='helvetica',fillcolor=z.color, style="filled")
        for i in range(0, highest_tactic_level):
            y = Tactic.objects.filter(name__icontains="ICS", level=(i)).first()
            z = Tactic.objects.filter(
                name__icontains="ICS", level__gt=i).order_by('level').first()
            G.add_edge(str(z.id), str(y.id), arrowsize=2.0, style="invis")

    # remove edgeless nodes in visualization (optional)
    if reductionlevel:
        G.remove_edges_from(nx.selfloop_edges(G))
        G = nx.k_core(G, k=reductionlevel)

    return G


def format_edge(node):
    """Helper function to identify and set the visualization of edges

    Args:
        node (Node object): A node of an attack graph

    Returns:
        style,color,label: attributes of an edge
    """
    style = ''
    color = 'lightgray'
    label = ""
    # successful
    if node.get_result == '0':
        style = "bold"
        color = "black"
        #label = "✓"
    # partially successful
    elif node.get_result == '1':
        style = "dashed"
        color = "black"
        #label = "❍"
    # unsuccessful
    elif node.get_result == '2':
        style = "dotted"
        color = "black"
        #label = "❌"
    return style, color, label


def format_node(node):
    """Helper function to identify and set the visualization of nodes

    Args:
        node (Node object): A node of an attack graph

    Returns:
        style, shape, fillcolor: attributes of a node
    """
    fillcolor = node.tactic.color
    if node.status == '2':  # executed
        style = "filled"
        shape = "box"
    elif node.status == '1':  # work in progress
        style = "filled,dashed"
        shape = "box"
    elif node.status == '0':
        style = "filled, dashed"
        shape = "plaintext"

    return style, shape, fillcolor


def random_name():
    """Generate a random name for APT naming. Random. Less useful. Just for fun. Uses a prefix
    from a fixed list and a set of main words from a fixed list. The suffix is randomly generated
    from numbers and letters for distinction purposes.

    Returns:
        [String] -- [Name of the fake APT group]
    """
    prefix = ['Fancy', 'Crouching', 'Charming', 'Deep', 'Epic', 'Dark', 'Wicked',
              'Obvious', 'Obnoxious', 'Electric', 'Irregular', 'Deputy', 'Shadow', 'Rare',
              'Unique', 'Shallow', 'Independent', 'Offensive', 'Ignorant', 'Eastern',
              'Western', 'Cyber', 'Flying', 'Unintended', 'Great', 'Crunchy', 'Busy']
    main = ['Hotel', 'APT', 'Armadillo', 'Aardvark', 'Yeti', 'Panda', 'Penguin', 'Bear',
            'Threat', 'UNC', 'Group', 'Kitten', 'Platypus', 'Cyber', 'Sloth', 'Wombat',
            'Coyote', 'Potassium', 'Helium', 'Plutonium', 'Palladium', 'Iridium',
            'Uranium', 'Unknown', 'Unit', 'Maze', 'Whale', 'Dutchman', 'Axolotl']
    # add a random number-suffix to prevent duplicates
    suffix = str(rnd.randint(0, 1337)) + "." + \
        rnd.choice(string.ascii_uppercase) + rnd.choice(string.ascii_uppercase)
    name = rnd.choice(prefix) + ' ' + rnd.choice(main) + ' ' + suffix
    return name
