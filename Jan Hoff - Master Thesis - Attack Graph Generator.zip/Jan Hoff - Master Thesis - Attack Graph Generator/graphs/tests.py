from django.test import TestCase # pylint: disable=import-error,unused-import

# Create your tests here.
# No tests implemented for the prototype