from django.apps import AppConfig


class GraphsConfig(AppConfig):
    """Enable an application called graphs

    Arguments:
        AppConfig {[type]} -- [description]
    """
    name = 'graphs'
