from .backend import render_img_graph, random_name, generate_graph_constrained
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
import pylab as plt  # pylint: disable=import-error,unused-import
from networkx.drawing.nx_agraph import graphviz_layout, to_agraph  # pylint: disable=import-error,unused-import
import pygraphviz as pgv  # pylint: disable=import-error,unused-import
import logging
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import HttpResponse
from .models import AttackGraph, Node, Technique, ThreatActor, Tactic, Target  # pylint: disable=import-error,unused-import
from django.shortcuts import render

from django.forms import formset_factory, modelformset_factory

from .forms import NewAdversaryForm, NodeEditForm, GraphEditForm

from django.db.models import F

logger = logging.getLogger(__name__)  # ?


@login_required  # decorator to force authenticated user
def index(request):
    """View to handle the index requests

    Args:
        request ([type]): [description]

    Returns:
        [type]: [description]
    """
    graphs = AttackGraph.objects.all().order_by('-id')[:5]
    context = {
        'graphs': graphs,
        'latest': AttackGraph.objects.latest('id').id
    }
    return render(request, 'graphs/index.html', context)


@login_required  # decorator to force authenticated user
def render_graph(request, graph_id, graph_format, reductionlevel=None):
    """View to handle graph rendering and handover to backend.py

    Args:
        request ([type]): [description]
        graph_id ([type]): [description]
        reductionlevel ([type], optional): [description]. Defaults to None.
        format (string): the format of the graph

    Returns:
        [type]: [description]
    """
    #evaluate parameters and generate correct MIME/filetype
    if graph_format == "svg":
        graph_format = "svg"
        graph_content_type = "image/svg+xml"
    elif graph_format == "png":
        graph_format = "png"
        graph_content_type = "application/force-download"
    elif graph_format == "json":
        graph_format = "json"
        graph_content_type = "application/force-download"
    elif graph_format == "jpg":
        graph_format = "jpg"
        graph_content_type = "application/force-download"
    else:
        graph_format = "svg"
        graph_content_type = "application/force-download"

    img = render_img_graph(graph_id, graph_format, reductionlevel)
    response = HttpResponse(img, content_type=graph_content_type)
    response['Content-Disposition'] = 'attachment; filename=%s' % "AttackGraph_"+str(graph_id)+"."+graph_format
    return response


@login_required  # decorator to force authenticated user
def new(request):
    """Process activity related to graph creation

    Args:
        request (Request): [description]

    Returns:
        rendered_request: Redirect to generated graph or show page again with errors/form data
    """
    # form has been posted
    if request.method == 'POST':
        form = NewAdversaryForm(request.POST)
        if form.is_valid():
            #node_number = form.cleaned_data['num_nodes']
            #num_edges = form.cleaned_data['num_edges']
            name = form.cleaned_data['name']
            desc = form.cleaned_data['desc']
            num_overstep = form.cleaned_data['num_overstep']
            spread = form.cleaned_data['spread']
            min_width = form.cleaned_data['min_width']
            max_width = form.cleaned_data['max_width']
            #compensate for deliberately wrong boundaries
            if (int(min_width) > int(max_width)):
                max_width = min_width
            tactic_constraints = form.cleaned_data['tactic_constraint']
            technique_constraints = form.cleaned_data['technique_constraint']
            target_constraints = form.cleaned_data['target_constraint']
            ioc_constraints = form.cleaned_data['ioc_constraint']
            group_constraints = form.cleaned_data['group_constraint']
            constraints = ({"tactics": tactic_constraints, "techniques": technique_constraints,
                            "targets": target_constraints, "iocs": ioc_constraints, "groups": group_constraints})
            new_attackgraph = generate_graph_constrained(
                name, desc, max_width, min_width, constraints, num_overstep, spread)
            # new_attackgraph = generate_graph(name, desc, node_number, num_edges, num_overstep) #legacy graph creation using no constraints and simply combine nodes & edges
            
            #if constraints are too strict (no attack generatable), show form again show error message
            if not new_attackgraph:
                form.add_error(None, "Constraints too strict to instantiate graph")           
                return render(request, 'graphs/new.html', {'form': form})
            return redirect('show_graph', graph_id=new_attackgraph.id)

    # generate a new web-form with default data
    else:
        name = request.GET.get('name', random_name())
        form = NewAdversaryForm(initial={
                                'name': name, 'desc': "...please write a few sentences about this attack simulation"})

    return render(request, 'graphs/new.html', {'form': form})


@login_required  # decorator to force authenticated user
def show_all(request):
    """View to handle graph rendering and handover to backend.py

    Args:
        request ([type]): [description]

    Returns:
        [type]: [description]
    """
    graph_list = AttackGraph.objects.all().order_by('-id')
    page = request.GET.get('page', 1)

    # create paginator to show the graph list
    paginator = Paginator(graph_list, 10)
    try:
        graphs = paginator.page(page)
    except PageNotAnInteger:
        graphs = paginator.page(1)
    except EmptyPage:
        graphs = paginator.page(paginator.num_pages)

    context = {
        'graphs': graphs
    }
    return render(request, 'graphs/show_all.html', context)


@login_required  # decorator to force authenticated user
def show_graph(request, graph_id):
    """View to handle graph detail view of a single graph
    Args:
        request ([type]): [description]
        graph_id ([type]): [description]

    Returns:
        [type]: [description]
    """

    #create list of all nodes in graph and annote nodes (built-in F-function) by techniques and targets for a better visualizaton
    list_of_nodes = Node.objects.filter(graph_id=graph_id).order_by('-tactic__level').annotate(techniquename=F('technique__name')).annotate(targetname=F('target__name')).values()
    NodeFormSet = formset_factory(NodeEditForm, extra=0)
    #parse POST data
    if request.method == 'POST':
        formset = NodeFormSet(request.POST)
        if formset.is_valid():
            #iterate over formset and update each node accordingly
            for form in formset:
                node_to_edit = Node.objects.filter(id=form.cleaned_data['id']).get()
                status = form.cleaned_data['status']
                result = form.cleaned_data['result']
                comment = form.cleaned_data['result_comment']
                node_to_edit.status=status
                node_to_edit.result=result
                node_to_edit.result_comment=comment
                node_to_edit.save()
            return redirect('show_graph', graph_id=graph_id)

    formset = NodeFormSet(initial=list_of_nodes)
    graph_status = GraphEditForm(initial={'status': AttackGraph.objects.filter(id=graph_id).get().status})

    context = {
        'graph': AttackGraph.objects.filter(id=graph_id).get(),
        'nodes': Node.objects.filter(graph_id=graph_id).order_by('-tactic__level'),
        'fields': Node.objects.filter(graph_id=graph_id).order_by('-tactic__level').__dict__,
        'formset' : formset,
        'graph_status' : graph_status
    }
    return render(request, 'graphs/show.html', context)


@login_required  # decorator to force authenticated user
def show_node(request, graph_id, node_id):
    """View to handle detail view of a single node and its parameters

    Args:
        request ([type]): [description]
        graph_id ([type]): [description]
        node_id ([type]): [description]

    Returns:
        [type]: [description]
    """
    node_to_edit = Node.objects.filter(id=node_id).get()
    if request.method == 'POST':

        form = NodeEditForm(request.POST)
        if form.is_valid():
            status = form.cleaned_data['status']
            result = form.cleaned_data['result']
            comment = form.cleaned_data['result_comment']
            node_to_edit.status=status
            node_to_edit.result=result
            node_to_edit.result_comment=comment
            node_to_edit.save()
            return redirect('show_graph', graph_id=graph_id)

    form = NodeEditForm(initial={'status': node_to_edit.status, 'result': node_to_edit.result, 'result_comment': node_to_edit.result_comment, 'id': node_to_edit.id})
    context = {
        'graph': AttackGraph.objects.filter(id=graph_id).get(),
        'node': Node.objects.filter(id=node_id).get(),
        'nodeform': form
    }
    return render(request, 'graphs/node.html', context)


def apt_name_generator(request):
    """View to handle graph rendering and handover to backend.py

    Arguments:
        request {[type]} -- [description]

    Returns:
        [type] -- [description]
    """
    names = []
    for _ in range(10):
        names.append(random_name())
    return render(request, 'graphs/apt_name_generator.html', {'names': names})


def database(request):
    """View to show database layout

    Args:
        request ([type]): [description]

    Returns:
        [type]: [description]
    """
    context = {}
    return render(request, 'graphs/database.html', context)


def system(request):
    """View to show system architecture

    Args:
        request ([type]): [description]

    Returns:
        [type]: [description]
    """
    context = {}
    return render(request, 'graphs/system.html', context)

@login_required  # decorator to force authenticated user
def update_node(request):
    """View to update an individual node (currently not used and handled with show node)

    Args:
        request ([type]): [description]

    Returns:
        [type]: [description]
    """
    context = {
    }
    return render(request, '', context)
