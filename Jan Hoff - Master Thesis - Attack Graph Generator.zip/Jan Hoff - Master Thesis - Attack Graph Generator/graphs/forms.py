from django import forms
from .models import Tactic, Technique, Target, Ioc, ThreatActor
from django.forms import ModelForm
from django.forms.widgets import TextInput, SelectMultiple, CheckboxSelectMultiple
from django.core.validators import MaxValueValidator, MinValueValidator
from .choices import STATUS,RESULTS, STATUS_GRAPH
from crispy_forms.helper import FormHelper

#forms for data enty

class NewAdversaryForm(forms.Form):
    """A form to create a new adversary with constraints.

    Args:
        forms ([type]): [description]
    """
    name = forms.CharField(label='Name of the Adversary', max_length=200)
    desc = forms.CharField(label='Description',
                           widget=forms.Textarea(attrs={'rows': '3'}))
    # num_nodes = forms.IntegerField(
    #    label='Minimal number of nodes', initial='15')
    # num_edges = forms.IntegerField(
    #    label='Additional number of edges', initial='10')
    num_overstep = forms.IntegerField(
        label='maximum number of overstepping transition', initial='1',widget = forms.HiddenInput())
    min_width = forms.IntegerField(
        label='minimum width of the graph', initial='1')
    max_width = forms.IntegerField(
        label='maximum width of the graph', initial='2')
    spread = forms.FloatField(
        label='Probability for edges (logarithmic float 0=equal distribution, 10=highest skew)', initial='2', validators=[MaxValueValidator(10, "Too big"), MinValueValidator(0, "Too small")],widget = forms.HiddenInput())
    tactic_constraint = forms.ModelMultipleChoiceField(queryset=Tactic.objects.filter(
        name__icontains="ICS").order_by('-level'), widget=CheckboxSelectMultiple(attrs={'size': 12}), required=False, label='Exclude tactics')
    technique_constraint = forms.ModelMultipleChoiceField(queryset=Technique.objects.filter(
        tactic__name__icontains="ICS").order_by('-tactic__level'), widget=SelectMultiple(attrs={'size': 20}), required=False, label='Exclude techniques')
    target_constraint = forms.ModelMultipleChoiceField(queryset=Target.objects.all(
    ), widget=SelectMultiple(attrs={'size': 20}), required=False, label='Exclude targets')
    group_constraint = forms.ModelMultipleChoiceField(queryset=ThreatActor.objects.all(
    ), widget=SelectMultiple(attrs={'size': 20}), required=False, label='Exclude groups')
    ioc_constraint = forms.ModelMultipleChoiceField(queryset=Ioc.objects.all(
    ), widget=SelectMultiple(attrs={'size': 20}), required=False, label='Exclude IOCs')


class NodeEditForm(forms.Form):
    """Form to change attributes of nodes (status/results)

    Args:
        forms ([type]): [description]
    """
    def __init__(self, *args, **kwargs):
        super(NodeEditForm, self).__init__(*args, **kwargs)
        #deactivate Form labels, since it is used in a table
        self.helper = FormHelper()
        self.helper.form_show_labels = False 
    
    id = forms.IntegerField()
    techniquename = forms.CharField(disabled=True,required=False)
    targetname = forms.CharField(disabled=True,required=False)
    status = forms.ChoiceField(choices=STATUS)
    result = forms.ChoiceField(choices=RESULTS)
    result_comment = forms.CharField(widget=forms.Textarea,required=False)


class GraphEditForm(forms.Form):
    """Form to edit graph attributes.

    Args:
        forms ([type]): [description]
    """
    id = forms.IntegerField()
    status = forms.ChoiceField(choices=STATUS_GRAPH)

class TacticAdminForm(ModelForm):
    """Modification of administrative form to show color picker on Technique manipulations.

    Args:
        ModelForm ([type]): [description]
    """
    class Meta:
        model = Tactic
        fields = '__all__'
        widgets = {
            'color': TextInput(attrs={'type': 'color'}),
        }

# class NodeAdminForm(ModelForm):
#     class Meta:
#         model = Node
#         fields = '__all__'
#         widgets = {
#             'color': TextInput(attrs={'type': 'color'}),
#         }
