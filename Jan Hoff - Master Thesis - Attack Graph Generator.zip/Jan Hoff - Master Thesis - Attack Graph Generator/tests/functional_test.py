from selenium import webdriver

browser = webdriver.Firefox()
browser.get('http://localhost:8000')

assert 'Attack graph' in browser.title

pass

#TODO add more Testcases
